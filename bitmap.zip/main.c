/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: andre
 *
 * Created on 13. November 2016, 20:54
 */

#include <stdio.h>
#include <stdlib.h>
#include "myError.h"
#include "myTypes.h"
#include "myConsts.h"
#include "Bitmap.h"
#include "RectangleFinder.h"
#include "RLE8.h"

/*
 * 
 */
int main(int argc, char** argv) {
    FILE *source = NULL;
    FILE *dest = NULL;
    BITMAPFILEHEADER *fileheader = NULL;
    BITMAPINFOHEADER *infoheader = NULL;
    RGBQUAD *colormap = NULL;
    BYTE *pixel8Bit = NULL;
    RGBTRIPLE *pixel24Bit = NULL;
    uint32_t offset;
    int usedColors;
    int width;
    int height;
    int indexRUL;
    int indexRUR;
    int indexRBL;
    int indexRBR;
    
    int indexGUL;
    int indexGUR;
    int indexGBL;
    int indexGBR;
    
    errNo = OK;
    
    source = openFile(BITMAP_SOURCE, READ_MODE);
    
    if (errNo != OK) {
        return errorHandling();
    }
    
    fileheader = readFileHeader(source);
    
    if (errNo != OK) {
        return errorHandling();
    }
    
    infoheader = readInfoHeader(source);
    
    if (errNo != OK) {
        free(fileheader);
        return errorHandling();
    }
    if (infoheader->biClrUsed == 0) {
        usedColors = MAX_USED_COLORS;
    } else {
        if (infoheader->biClrUsed > 0 && infoheader->biClrUsed < MAX_USED_COLORS) {
            usedColors = infoheader->biClrUsed;
        } else {
            errNo = COLORMAP_ERROR;
        }
    }
    
    height = infoheader->biHeight;
    width = infoheader->biWidth;
    offset = fileheader->bfOffBits;
    
    printf("%d x %d\n", width , height);
    
    if (errNo != OK) {
        free(fileheader);
        free(infoheader);
        return errorHandling();
    }
    
    if (infoheader->biBitCount == 8) {
    
        colormap = readColormap(source, usedColors);
    
        if (errNo != OK) {
            free(fileheader);
            free(infoheader);
            return errorHandling();
        }
    
        if (infoheader->biCompression == 1) {
            pixel8Bit = rleDecompress(source, width, height);
        } else {
            pixel8Bit = readPixel(source, width, height);
        }
        
        if (errNo != OK) {
            free(fileheader);
            free(infoheader);
            free(colormap);
            return errorHandling();
        }
    
        pixel24Bit = convertPixel(width, height, colormap, pixel8Bit);
    
        if (errNo != OK) {
            free(fileheader);
            free(infoheader);
            free(colormap);
            return errorHandling();
        }
    } else {
        if (infoheader->biCompression != 0) {
            errNo = CANT_COMPRESS;
            return errorHandling();
        }
        pixel24Bit = read24BitPixel(source, width, height);
        
    }
    
    closeFile(source);
    
    if (errNo != OK) {
        free(fileheader);
        free(infoheader);
        free(colormap);
        return errorHandling();
    }
    
    findRedRectangle(pixel24Bit, width, height, &indexRBL, &indexRBR, &indexRUL, &indexRUR);
    
    if (errNo != OK) {
        free(fileheader);
        free(infoheader);
        if (colormap != NULL) {
            free(colormap);
        }
        if (pixel8Bit != NULL) {
            free(pixel8Bit);
        }
        if (pixel24Bit != NULL) {
            free(pixel24Bit);
        }
        return errorHandling();
    }
    
    findGreenRectangle(pixel24Bit, width, height, &indexGBL, &indexGBR, &indexGUL, &indexGUR);
    
    if (errNo != OK) {
        free(fileheader);
        free(infoheader);
        if (colormap != NULL) {
            free(colormap);
        }
        if (pixel8Bit != NULL) {
            free(pixel8Bit);
        }
        if (pixel24Bit != NULL) {
            free(pixel24Bit);
        }
        return errorHandling();
    }
    
    findFramePoints(pixel24Bit, width, indexRBL, indexRBR, indexRUL, indexRUR, indexGBL, indexGBR, indexGUL, indexGUR);
    
    if (errNo != OK) {
        free(fileheader);
        free(infoheader);
        if (colormap != NULL) {
            free(colormap);
        }
        if (pixel8Bit != NULL) {
            free(pixel8Bit);
        }
        if (pixel24Bit != NULL) {
            free(pixel24Bit);
        }
        return errorHandling();
    }
    
    fileheader = convertFileHeader(fileheader);
    infoheader = convertInfoHeader(infoheader);
    
    if (errNo != OK) {
        free(fileheader);
        free(infoheader);
        if (colormap != NULL) {
            free(colormap);
        }
        if (pixel8Bit != NULL) {
            free(pixel8Bit);
        }
        if (pixel24Bit != NULL) {
            free(pixel24Bit);
        }
        return errorHandling();
    }
    
    
    dest = openFile(BITMAP_DESTINATION, WRITE_MODE);
    
    if (errNo != OK) {
        fclose(dest);
        free(fileheader);
        free(infoheader);
        if (colormap != NULL) {
            free(colormap);
        }
        if (pixel8Bit != NULL) {
            free(pixel8Bit);
        }
        if (pixel24Bit != NULL) {
            free(pixel24Bit);
        }
        return errorHandling();
    }
    
    errNo = writeFile(dest, fileheader, infoheader, pixel24Bit, width, height);
    
    if (errNo != OK) {
        fclose(dest);
        free(fileheader);
        free(infoheader);
        if (colormap != NULL) {
            free(colormap);
        }
        if (pixel8Bit != NULL) {
            free(pixel8Bit);
        }
        if (pixel24Bit != NULL) {
            free(pixel24Bit);
        }
        return errorHandling();
    }
    
    closeFile(dest);
    
    free(fileheader);
    free(infoheader);
    free(colormap);
    free(pixel8Bit);
    free(pixel24Bit);
    
    return (EXIT_SUCCESS);
}

